const LoginPage = () => {
    return (
        <div>
            <h1>LoginPage</h1>
        </div>
    )
}

export default LoginPage
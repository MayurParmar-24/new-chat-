const ProfilePage = () => {
    
    return (
        <div>
            <h1>ProfilePage</h1>
        </div>
    )
}

export default ProfilePage
const SettingsPage = () => {
    return (
        <div>
            <h1>SettingsPage</h1>
        </div>
    )
}

export default SettingsPage